<?php

namespace Addons\QrAdmin\Model;
use Think\Model;

/**
 * QrAdmin模型
 */
class QrAdminModel extends Model{

}
