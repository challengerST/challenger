<?php
return array (
	'is_close'=>array(
		'title' => '开启消息模板',
		'type' => 'radio',
		'options'=>array(
				0=>'开启',
				1=>'关闭'
		),
		'value' => '0',
		'tip'=>''
	),
	'libaoling' => array (
			'title' => '礼包领取通知 模板ID',
			'type' => 'text',
			'value' => '',
			'tip'=>'礼包领取通知消息模板 编号 OPENTM200977411'
	),
    'libaoshi' => array (
        'title' => '礼包发放失败通知 模板ID',
        'type' => 'text',
        'value' => '',
        'tip'=>'礼包发放失败通知 模板 编号 TM00384'
    ),
    'youhuijuan' => array (
        'title' => '优惠券领取成功通知 模板ID',
        'type' => 'text',
        'value' => '',
        'tip'=>'优惠券领取成功通知 模板 编号 OPENTM200474379'
    ),
	
    'daijinjuan' => array (
        'title' => '获得代金券通知 模板ID',
        'type' => 'text',
        'value' => '',
        'tip'=>'获得代金券通知 模板 编号 TM00483'
    ),
    'fangxian' => array (
        'title' => '返现到账通知 模板ID',
        'type' => 'text',
        'value' => '',
        'tip'=>'返现到账通知 模板 编号 OPENTM205223929'
    ),
    
);
					