<?php

namespace Addons\AutoReply\Model;
use Think\Model;

/**
 * AutoReply模型
 */
class AutoReplyModel extends Model{

}
