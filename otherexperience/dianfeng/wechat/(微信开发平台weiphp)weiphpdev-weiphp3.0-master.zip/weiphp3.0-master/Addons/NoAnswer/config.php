<?php
return array (
    'stype'=>array(
        'title'=>'选择类型',
        'type'=>'material',
        'value'=>''
    ),
);
					